"""Build the cases and render the assembly views without opening a CAD window."""
import cadquery as cq
from cadquery.vis import show
from pathlib import Path
import build

HERE=Path(__file__).resolve().parent
previews,report=build.main()
colors={'base':cq.Color(.18,.25,.30),'lid':cq.Color(.72,.79,.82),
        'keys':cq.Color(.10,.12,.14),'pcb':cq.Color(.12,.48,.28),
        'battery':cq.Color(.45,.68,.88),'metal':cq.Color(.6,.62,.66)}


def add(assembly,shape,name,color,offset):
    assembly.add(shape,name=name,color=color,loc=cq.Location(cq.Vector(*offset)))


def render(assembly,path,elevation=-52,azimuth=25):
    show(assembly,screenshot=str(HERE/path),interact=False,width=1800,height=1250,
         roll=0,elevation=elevation,azimuth=azimuth,orthographic=True,trihedron=False,
         bgcolor=(.96,.97,.98),gradient=False,fxaa=True,tolerance=.03,zoom=1.05,specular=False)

assembled=cq.Assembly(name='clicker_cases')
for name,offset in [('remote',(0,0,0)),('receiver',(68,9,0))]:
    parts,fixtures,params=previews[name]
    add(assembled,parts[name+'_base'],name+'_base',colors['base'],offset)
    add(assembled,parts[name+'_lid'],name+'_lid',colors['lid'],offset)
    add(assembled,fixtures['electronics'],name+'_pcb',colors['pcb'],offset)
    add(assembled,fixtures['usb'],name+'_usb',colors['metal'],offset)
    if name=='remote':
        for k in ['SW1_cap','SW2_cap']:
            add(assembled,fixtures[k],k,colors['keys'],offset)
render(assembled,'preview.png')

exploded=cq.Assembly(name='remote_inside')
parts,fixtures,params=previews['remote']
add(exploded,parts['remote_base'],'base',colors['base'],(0,0,0))
add(exploded,fixtures['battery'],'battery',colors['battery'],(0,0,12))
add(exploded,fixtures['electronics'],'pcb',colors['pcb'],(0,0,18))
add(exploded,fixtures['usb'],'usb',colors['metal'],(0,0,18))
for k in ['SW1_body','SW1_stem','SW2_body','SW2_stem']:
    add(exploded,fixtures[k],k,colors['keys'],(0,0,18))
add(exploded,parts['remote_lid'],'lid',colors['lid'],(0,0,40))
for k in ['SW1_cap','SW2_cap']:
    add(exploded,fixtures[k],k,colors['keys'],(0,0,50))
render(exploded,'remote-exploded.png',elevation=-70,azimuth=22)

underside=cq.Assembly(name='remote_underside')
add(underside,parts['remote_base'],'base',colors['base'],(0,0,0))
add(underside,fixtures['electronics'],'pcb',colors['pcb'],(0,0,0))
render(underside,'remote-underside.png',elevation=150,azimuth=18)
