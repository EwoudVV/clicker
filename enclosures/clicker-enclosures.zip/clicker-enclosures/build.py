#!/usr/bin/env python3
"""Clicker cases. Dimensions are millimetres. Run from any directory."""
from pathlib import Path
import json, hashlib, math
import cadquery as cq
import trimesh

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DATA = json.loads((HERE / 'measurements.json').read_text())
OUT = HERE / 'stl'
OUT.mkdir(exist_ok=True)
WORK = HERE / 'reference'

# Fit settings. Check the stem coupon and screw fit before final assembly.
WALL = 2.0
FLOOR = 2.0
LID = 2.6
PCB_SIDE_GAP = 0.35
PCB_TOP_GAP = 0.30
LIP_GAP = 0.25
PILOT_D = 1.7
SCREW_CLEARANCE_D = 2.4
HEAD_D = 4.6
HEAD_DEPTH = 1.6
CAP_W, CAP_L = 17.0, 15.4
STEM_W, STEM_L, STEM_PITCH, STEM_INSERTION = 1.15, 2.95, 5.70, 2.20


def box(x0, x1, y0, y1, z0, z1):
    return cq.Solid.makeBox(x1-x0, y1-y0, z1-z0, cq.Vector(x0,y0,z0))


def rounded(w, length, z0, z1, radius, x=0, y=0):
    return (cq.Workplane('XY').center(x,y).rect(w,length).extrude(z1-z0)
            .edges('|Z').fillet(radius).val().translate((0,0,z0)))


def cylinder(x, y, r, z0, z1):
    return cq.Solid.makeCylinder(r,z1-z0,cq.Vector(x,y,z0))


def bounds(s):
    b=s.BoundingBox()
    return [b.xmin,b.xmax,b.ymin,b.ymax,b.zmin,b.zmax]


def fp(name, ref):
    return next(f for f in DATA[name]['footprints'] if f['ref']==ref)


def move(s, dz=0, dy=0):
    return s.translate((0,dy,dz))


def intersection_volume(a,b):
    return a.intersect(b).Volume()


def export_print(s, name, flip=False):
    if flip:
        s=s.rotate((0,0,0),(1,0,0),180)
    b=s.BoundingBox()
    s=s.translate((-b.center.x,-b.center.y,-b.zmin))
    path=OUT/f'{name}.stl'
    cq.exporters.export(s,str(path),tolerance=0.035,angularTolerance=0.12)
    mesh=trimesh.load(path,force='mesh')
    assert mesh.is_watertight, f'{name}: open mesh'
    assert mesh.is_winding_consistent and mesh.volume>0, f'{name}: bad winding'
    assert len(mesh.split())==1, f'{name}: disconnected print'
    return {'file':str(path.relative_to(HERE)),'size_mm':mesh.extents.round(3).tolist(),
            'volume_mm3':round(mesh.volume,2),'watertight':True,'connected_solids':1}


def keycap(direction='left', stem_width=STEM_W):
    body=rounded(CAP_W,CAP_L,0,2.2,1.0)
    body=cq.Workplane(obj=body).faces('>Z').edges().chamfer(.35).val()
    for x in (-STEM_PITCH/2,STEM_PITCH/2):
        stem=box(x-stem_width/2,x+stem_width/2,-STEM_L/2,STEM_L/2,-STEM_INSERTION,.1)
        # A short lead-in on the tips makes insertion less likely to split a stem.
        stem=cq.Workplane(obj=stem).faces('<Z').edges().chamfer(.12).val()
        body=body.fuse(stem)
    arrow=[(-2.8,0),(.2,2.6),(1.15,1.6),(-.6,0),(1.15,-1.6),(.2,-2.6)]
    if direction=='right':arrow=[(-x,y) for x,y in arrow]
    mark=cq.Workplane('XY').polyline(arrow).close().extrude(.55).val().translate((0,0,1.75))
    return body.cut(mark).clean()


def switch_proxy(x,y,pcb_top):
    body=rounded(13.8,13.8,pcb_top,pcb_top+5.0,.7,x,y)
    body=body.fuse(rounded(15,15,pcb_top+2.2,pcb_top+3.0,.7,x,y))
    # This is a clearance model, not a detailed model of the switch internals.
    body=body.cut(box(x-3.85,x+3.85,y-2.4,y+2.4,pcb_top+1.8,pcb_top+5.2))
    stem=box(x-3.7,x+3.7,y-2.25,y+2.25,pcb_top+5,pcb_top+8)
    for sx in (-STEM_PITCH/2,STEM_PITCH/2):
        stem=stem.cut(box(x+sx-.6,x+sx+.6,y-1.5,y+1.5,pcb_top+5,pcb_top+8.1))
    return body,stem


def make_case(name):
    d=DATA[name]
    current=ROOT/name/f'{name}.kicad_pcb'
    assert not current.exists() or hashlib.sha256(current.read_bytes()).hexdigest()==d['board_sha256'], \
        f'{name} PCB changed. Run prepare.py before rebuilding.'
    remote=name=='remote'
    half=d['board_bounds'][1]
    front=d['board_bounds'][2]
    antenna_end=d['assembly_bounds'][3]
    pcb_z=13.5 if remote else 4.5
    pcb_top=pcb_z+1.6
    seam=pcb_top+4.0 if remote else 15.6
    top=seam+LID
    width=60.0 if remote else 34.0
    body_x=7.0 if remote else 0.0
    y0=-38.5 if remote else front-3.5
    y1=antenna_end+3.5
    cy=(y0+y1)/2
    length=y1-y0
    radius=6.0 if remote else 4.5
    screws=([(-18.5,-32.5),(-18.5,1.5),(31.5,-33.5),(31.5,12.0)] if remote
            else [(x,y) for x in (-13.25,13.25) for y in (-17.5,0)])
    supports=([(-1,-25.5,2.2),(-1,-7,2.2),(-1,25,2.2),
               (1,-32.8,1.2),(1,11,2.2),(1,25,2.2)] if remote
              else [(side,y,2.2) for side in (-1,1) for y in (-10.8,11)])
    boss_r=2.8 if remote else 2.4

    outer=rounded(width,length,0,seam,radius,x=body_x,y=cy)
    outer=cq.Workplane(obj=outer).faces('<Z').edges().chamfer(.35).val()
    cavity=rounded(width-2*WALL,length-2*WALL,FLOOR,seam+.2,radius-WALL,x=body_x,y=cy)
    base=outer.cut(cavity)
    lid=rounded(width,length,seam,top,radius,x=body_x,y=cy)
    lid=cq.Workplane(obj=lid).faces('>Z').edges().chamfer(.45).val()
    lip_outer=rounded(width-2*WALL-2*LIP_GAP,length-2*WALL-2*LIP_GAP,seam-1.6,seam+.05,
                      radius-WALL-LIP_GAP,x=body_x,y=cy)
    lip_inner=rounded(width-2*WALL-2*LIP_GAP-2,length-2*WALL-2*LIP_GAP-2,seam-1.7,seam+.2,
                      radius-WALL-LIP_GAP-1,x=body_x,y=cy)
    lip=lip_outer.cut(lip_inner)
    for x,y in screws:
        lip=lip.cut(cylinder(x,y,boss_r+.35,seam-1.8,seam+.2))
        base=base.fuse(cylinder(x,y,boss_r,FLOOR-.3,seam))
        base=base.cut(cylinder(x,y,PILOT_D/2,seam-6.3,seam+.1))
        lid=lid.cut(cylinder(x,y,SCREW_CLEARANCE_D/2,seam-.1,top+.1))
        lid=lid.cut(cylinder(x,y,HEAD_D/2,top-HEAD_DEPTH,top+.1))
    lid=lid.fuse(lip)

    # Edge saddles support the PCB without drilling it or pressing on components.
    for side,sy,hy in supports:
        inset=3.0 if remote and side==1 and sy < -30 else .5
        a,b=side*(half-inset),body_x+side*(width/2-WALL+.35)
        x0,x1=sorted((a,b))
        if remote and side==-1:
            pts=[(a,pcb_z),(b,pcb_z),(b,FLOOR-.2),(b-side*1.3,FLOOR-.2)]
            saddle=(cq.Workplane('XZ').polyline(pts).close().extrude(hy,both=True)
                    .val().translate((0,sy,0)))
        else:
            saddle=box(x0,x1,sy-hy,sy+hy,FLOOR-.2,pcb_z)
        base=base.fuse(saddle)
        ga,gb=sorted((side*(half+PCB_SIDE_GAP),b))
        base=base.fuse(box(ga,gb,sy-hy,sy+hy,pcb_z-.1,pcb_top+.05))
        la,lb=sorted((a,body_x+side*(width/2-WALL-LIP_GAP)))
        lid=lid.fuse(box(la,lb,sy-hy+.2,sy+hy-.2,pcb_top+PCB_TOP_GAP,seam+.15))
    for x,y in screws:
        lid=lid.cut(cylinder(x,y,boss_r+.35,pcb_top+.05,seam))

    usb_x,usb_y=fp(name,'J1')['center']
    # F.Fab is 8.94 x 7.30 mm. Use a conservative 3.5 mm shell envelope.
    usb_face=usb_y-3.65
    usb_z=pcb_top+1.63
    usb_body=box(usb_x-4.6,usb_x+4.6,usb_face,usb_face+7.5,pcb_top,pcb_top+3.5)
    # Room for the moulded cable end, plus a shorter metal plug throat.
    plug=box(usb_x-6.5,usb_x+6.5,y0-15,usb_face+.2,usb_z-3.8,usb_z+3.8)
    plug=plug.fuse(box(usb_x-4.8,usb_x+4.8,front-.4,usb_face+.3,usb_z-1.55,usb_z+1.55))
    base=base.cut(plug)
    lid=lid.cut(plug)

    # Pinhole guides stop above BOOT/RESET. They do not preload the switches.
    guides=[]
    for ref in ('SW_BOOT','SW_RST'):
        x,y=fp(name,ref)['center']
        bottom=pcb_z+fp(name,ref)['bounds'][5]+.65
        guides.append(cylinder(x,y,1.7,bottom,seam+.1))
        lid=lid.fuse(guides[-1])
        lid=lid.cut(cylinder(x,y,1.05,bottom-.1,top+.1))
    if not remote:
        # Join the two slender guides so they cannot flex apart.
        x,y=fp(name,'SW_BOOT')['center']; ry=fp(name,'SW_RST')['center'][1]
        bridge=box(x-1.7,x+1.7,min(y,ry),max(y,ry),pcb_z+3.195+.65,seam+.1)
        for yy in (y,ry):bridge=bridge.cut(cylinder(x,yy,1.05,0,top+.1))
        lid=lid.fuse(bridge)
    leds=('D_CHG','D_STAT') if remote else ('D1',)
    for ref in leds:
        x,y=fp(name,ref)['center']
        lid=lid.cut(cylinder(x,y,1.6,seam-1.8,top+.1))

    pieces={f'{name}_base':base,f'{name}_lid':lid}
    fixtures={}
    fixtures['electronics']=move(cq.importers.importStep(str(WORK/f'{name}.step')).val(),pcb_z)
    fixtures['board']=move(cq.importers.importStep(str(WORK/f'{name}-board.step')).val(),pcb_z)
    fixtures['usb']=usb_body
    fixtures['usb_cable_envelope']=plug
    caps=[]
    if remote:
        switch_points=[fp(name,r)['center'] for r in ('SW1','SW2')]
        # One clean key bay avoids a fragile 0.1 mm strip between the keys.
        low=min(p[1] for p in switch_points)-CAP_L/2-.5
        high=max(p[1] for p in switch_points)+CAP_L/2+.5
        mx=sum(p[0] for p in switch_points)/2
        bay=rounded(CAP_W+1.1,high-low,seam-2,top+.1,1.0,x=mx,y=(low+high)/2)
        cx,cy_led=fp(name,'D_CHG')['center']
        bay=bay.fuse(cylinder(cx,cy_led,1.8,seam-2,top+.1))
        # Connect the charge-light notch to the main opening, with no thin web.
        bay=bay.fuse(box(cx-1.8,cx+1.8,cy_led,low+1,seam-2,top+.1))
        lid=lid.cut(bay)
        for ref,direction in [('SW1','left'),('SW2','right')]:
            x,y=fp(name,ref)['center']
            cap=keycap(direction).translate((x,y,pcb_top+8))
            caps.append((ref,cap))
            fixed,stem=switch_proxy(x,y,pcb_top)
            fixtures[ref+'_body']=fixed
            fixtures[ref+'_stem']=stem
            fixtures[ref+'_cap']=cap
        pieces['keycap_previous']=keycap('left')
        pieces['keycap_next']=keycap('right')

        # Battery tray allows 0.75 mm per side and extra thickness; tape holds it.
        bat_x,bat_y=19.25,-11.0
        tray=rounded(32.1,39.6,FLOOR-.15,FLOOR+1.8,2.0,x=bat_x,y=bat_y)
        tray=tray.cut(rounded(30.5,38.0,FLOOR-.3,FLOOR+2.0,.5,x=bat_x,y=bat_y))
        # Cable notches through both ends of the shallow tray wall.
        for yy in (bat_y-19,bat_y+19):
            tray=tray.cut(box(bat_x-3,bat_x+3,yy-1.5,yy+1.5,FLOOR-.1,FLOOR+2.1))
        tray=tray.cut(box(2.5,5.0,-24,-12,FLOOR-.1,FLOOR+2.1))
        base=base.fuse(tray)
        fixtures['battery']=rounded(29,36,2.5,7.25,1.0,x=bat_x,y=bat_y)
        fixtures['battery_space']=rounded(30.5,38,2.5,8.5,1.0,x=bat_x,y=bat_y)
        bx,by=fp(name,'J_BAT')['center']
        fixtures['battery_plug_space']=box(-3.8,3.5,-23,-13.5,pcb_z-11,pcb_z-4.5)

        # The power switch is reached directly through a recessed thumb opening.
        sx,sy=-10.95,12.05
        travel=2.0
        slot=rounded(17,13,-.2,FLOOR+.3,3.0,x=sx,y=sy+travel/2)
        mouth=(cq.Workplane('XY').workplane(offset=-.1).center(sx,sy+travel/2)
               .rect(19,15).workplane(offset=1.2).rect(17,13).loft().val())
        base=base.cut(slot.fuse(mouth))
        fixtures['power_switch_access']=box(sx-3,sx+3,sy-2.5,sy+travel+2.5,-.1,pcb_z-8.5)

    # Recut after adding the guides so the whole cable envelope stays clear.
    base=base.cut(plug)
    lid=lid.cut(plug)

    # Small recessed labels, with no lettering through the shell.
    word='clicker'
    label_y=29 if remote else 16.5
    mark=cq.Workplane('XY').text(word,4.2 if remote else 2.8,.45,font='Arial',combine=True).val()
    lid=lid.cut(mark.translate((0,label_y,top-.35)))
    pieces[f'{name}_base']=base.clean()
    pieces[f'{name}_lid']=lid.clean()
    for label,solid in pieces.items():
        assert solid.isValid() and len(solid.Solids())==1, f'{label}: invalid solid'
    contact={}
    lowered_board=move(fixtures['board'],-.01)
    for side,sy,hy in supports:
        region=box(-width,width,sy-hy,sy+hy,pcb_z-.02,pcb_z+.02)
        region=region.intersect(box(-width if side==-1 else 0,
                                     0 if side==-1 else width,sy-hy,sy+hy,pcb_z-.02,pcb_z+.02))
        area=pieces[f'{name}_base'].intersect(region).intersect(lowered_board).Volume()/.01
        assert area>.3, f'{name}: support at {side}, {sy} misses the PCB'
        contact[f'{"left" if side==-1 else "right"}_{sy}']=round(area,3)
    return pieces,fixtures,{'pcb_z':pcb_z,'pcb_top':pcb_top,'seam':seam,'top':top,
             'width':width,'length':length,'screws':screws,'caps':caps,'front':front,
             'body_center_x':body_x,'overall_height':pcb_top+10.2 if remote else top,
             'support_contact_area_mm2':contact,
             'usb_face':usb_face,'antenna_end':antenna_end}


def validate(name,pieces,fixtures,params):
    base=pieces[name+'_base'];lid=pieces[name+'_lid']
    results={}
    pairs={'base/lid':(base,lid),'base/electronics':(base,fixtures['electronics']),
           'lid/electronics':(lid,fixtures['electronics']),
           'base/USB':(base,fixtures['usb']),'lid/USB':(lid,fixtures['usb']),
           'base/cable':(base,fixtures['usb_cable_envelope']),
           'lid/cable':(lid,fixtures['usb_cable_envelope'])}
    if name=='remote':
        for label in ['battery_space','battery_plug_space','power_switch_access']:
            for part,obj in [('base',base),('lid',lid)]:pairs[part+'/'+label]=(obj,fixtures[label])
        pairs['battery/plug']=(fixtures['battery_space'],fixtures['battery_plug_space'])
        pairs['battery/electronics']=(fixtures['battery_space'],fixtures['electronics'])
        for ref,cap in params['caps']:
            for part,obj in [('base',base),('lid',lid)]:
                pairs[f'{ref}/body/{part}']=(fixtures[ref+'_body'],obj)
            for dz in [0,-1.5,-3.0]:
                pairs[f'{ref}/lid/travel{dz}']=(move(cap,dz),lid)
                pairs[f'{ref}/electronics/travel{dz}']=(move(cap,dz),fixtures['electronics'])
        pairs['keycap gap']=(params['caps'][0][1],params['caps'][1][1])
    for label,(a,b) in pairs.items():
        volume=intersection_volume(a,b)
        results[label]=round(volume,6)
        if volume>0.0001:print('INTERFERENCE',name,label,volume,flush=True)
    return results


def main():
    report={'units':'mm','physical_fit_tested':False,'parts':{},'intersections_mm3':{},'cases':{}}
    previews={}
    for name in ['remote','receiver']:
        print('Building',name,flush=True)
        pieces,fixtures,params=make_case(name)
        checks=validate(name,pieces,fixtures,params)
        report['intersections_mm3'][name]=checks
        report['cases'][name]={k:v for k,v in params.items() if k!='caps'}
        for label,solid in pieces.items():
            flip=label.endswith('_lid') or label.startswith('keycap')
            report['parts'][label]=export_print(solid,label,flip)
        assembly=cq.Assembly(name=name)
        assembly.add(pieces[name+'_base'],name='base',color=cq.Color(.23,.29,.34))
        assembly.add(pieces[name+'_lid'],name='lid',color=cq.Color(.77,.81,.82))
        assembly.add(fixtures['electronics'],name='pcb_reference',color=cq.Color(.10,.43,.24))
        assembly.add(fixtures['usb'],name='usb_envelope',color=cq.Color(.60,.62,.65))
        if name=='remote':
            assembly.add(fixtures['battery'],name='battery_reference',color=cq.Color(.38,.63,.88))
            for key in ['SW1_body','SW1_stem','SW2_body','SW2_stem','SW1_cap','SW2_cap']:
                assembly.add(fixtures[key],name=key,color=cq.Color(.16,.17,.19) if 'cap' in key else cq.Color(.55,.55,.55))
        assembly.export(str(HERE/f'{name}.step'))
        previews[name]=(pieces,fixtures,params)
    (HERE/'fit-check.json').write_text(json.dumps(report,indent=2)+'\n')
    failed=[(n,k,v) for n,checks in report['intersections_mm3'].items() for k,v in checks.items() if v>.0001]
    print('Interferences:',failed,flush=True)
    assert not failed, 'Resolve the reported interferences before using these files.'
    coupon=rounded(56,12,0,1.8,1)
    for x,w in [(-22,1.05),(0,1.10),(22,1.15)]:
        for dx in [-STEM_PITCH/2,STEM_PITCH/2]:
            st=box(x+dx-w/2,x+dx+w/2,1.5-STEM_L/2,1.5+STEM_L/2,-STEM_INSERTION,.1)
            st=cq.Workplane(obj=st).faces('<Z').edges().chamfer(.12).val()
            coupon=coupon.fuse(st)
        t=cq.Workplane('XY').text(f'{w:.2f}',2.1,.4,font='Arial').val().translate((x,-3,1.5))
        coupon=coupon.cut(t)
    report['parts']['stem_fit_coupon']=export_print(coupon.clean(),'stem_fit_coupon',True)
    report['hardware']={'M2x6_pan_head_screws':8,'pilot_diameter_mm':PILOT_D,
                        'maximum_head_diameter_mm':4.2,'maximum_head_height_mm':1.6}
    report['fit_settings']={'pcb_side_gap_mm':PCB_SIDE_GAP,'pcb_top_gap_mm':PCB_TOP_GAP,
        'lid_lip_gap_mm':LIP_GAP,'keycap_gap_mm':1.1,'keycap_stem_mm':[STEM_W,STEM_L,STEM_INSERTION],
        'stem_pitch_mm':STEM_PITCH,'switch_travel_mm':3.0,'power_slider_travel_mm':2.0}
    (HERE/'fit-check.json').write_text(json.dumps(report,indent=2)+'\n')
    return previews,report

if __name__=='__main__':main()
