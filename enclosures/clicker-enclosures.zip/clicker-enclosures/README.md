# Clicker cases

Printed cases for the remote and receiver. The PCB files are unchanged. Both boards sit on edge supports and are held down by the lids, so they do not need mounting holes.

These are first-print designs. I do not have the assembled boards yet, so the fit has only been checked in CAD.

## Files

- `clicker-print-plate.3mf`: all parts arranged in their print orientation, with millimetre units. Choose the printer and material in the slicer.
- `stl/`: individual parts, already turned the right way up for printing.
- `remote.step` and `receiver.step`: assembled cases with the board references.
- `build.py`: editable case dimensions and geometry.
- `fit-check.json`: mesh checks and interference results for the current build.

The reference models are under `reference/`. They are for checking the fit, not for printing.

## Remote

The body is 60 x 80.8 x 21.7 mm, or 25.3 mm tall including the keycaps. The battery sits beside the lower part of the PCB. This makes the case wider but avoids stacking the battery underneath the connectors. There are no separate feet or power-slider parts.

The tray is sized for the [Adafruit 500 mAh cell](https://www.adafruit.com/product/1578), with a nominal size of 29 x 36 x 4.75 mm. The space reserved for it is 30.5 x 38 x 6 mm. Attach it with a small piece of thin removable tape; the tray should not squeeze the pouch. Tuck the wire into the side opening and keep it off the PCB supports and screw posts. The model reserves space for the mated battery plug and wire bend, but the actual lead routing still needs to be checked with the parts in hand.

The slide switch is reached through the opening underneath. Its tip is recessed about 4.7 mm from the bottom face. Check that it is easy to move through both positions before installing the battery. A physical build is still needed to check the feel of this opening.

Fit the board onto the ledges, then lower the lid and install four M2 x 6 mm screws with heads no wider than 4.2 mm and no taller than 1.6 mm. Press the keycaps onto the switches only after checking the stem coupon. BOOT and RESET have small access holes, and the charge and status LEDs have sight holes.

The USB opening allows a cable end up to 13 x 7.6 mm. The connector is recessed, so check that the cable seats fully before tightening the case.

## Receiver

The body is 34 x 46.59 x 18.2 mm. The tall programming header sets most of its height. There is a USB-C opening, an LED hole, and two small holes for BOOT and RESET.

Set the board on the supports with the USB port facing the opening. Check that it sits flat, then lower the lid over it. Use four M2 x 6 mm screws with heads no wider than 4.2 mm and no taller than 1.6 mm. The printed pilot holes are 1.7 mm. Start the screws gently and stop as soon as the lid is seated.

The USB opening allows for a cable end up to 13 mm wide and 7.6 mm tall. A larger cable may not fit. The USB jack does not have a usable model in the board files, so its clearance is based on the footprint and a conservative shell envelope.

Use a blunt pin through the BOOT and RESET holes. The guides stop above the buttons and should not hold them down.

## Keycaps

The two switch centres are 16.5 mm apart. The printed caps are 17 x 15.4 mm, leaving a nominal 1.1 mm gap between them. The PCB layout stays the same.

Print `stem_fit_coupon.stl` first when the switches arrive. It has three pairs of Choc stems, marked with widths of 1.05, 1.10, and 1.15 mm. Try the smallest first. A stem should seat without forcing or spreading the switch socket. The caps currently use 1.15 mm stems; change `STEM_W` in `build.py` and rebuild if another size fits better. Slot length and insertion depth may also need adjustment for the printer.

The cap model has been checked through 3 mm of downward travel. The stem fit still needs a physical check.

## Printing

Use PLA or PETG with about 0.16 to 0.20 mm layers and at least three walls. The bases print floor-down, the lids print outside-down, and the keycaps print face-down with the stems pointing up. The STL files already use these orientations.

Check the slicer preview around the USB openings, small guides, screw holes, and keycap stems. Clear any stringing or elephant foot from the mating edges before assembly. The lid tongue has 0.25 mm clearance per side; adjust `LIP_GAP` if the printer needs more room.

## Rebuilding

Use Python with CadQuery and trimesh installed. From this directory:

```sh
python3 render.py
python3 plate.py
```

`render.py` also runs the build. Use `python3 build.py` instead if only the STEP and STL files are needed.

If a PCB changes, run `python3 prepare.py` first to refresh the reference models and measurements. This needs KiCad's `kicad-cli` and access to the footprint 3D models. Set `KICAD_CLI` if it is not on the usual path. The build checks the board hashes so an old reference cannot silently be used with a changed PCB.

The checks cover solid validity, connected watertight meshes, model interference, key travel, and print-plate spacing. They do not verify solder height, battery lead routing, printer tolerances, or the feel of the assembled buttons.
